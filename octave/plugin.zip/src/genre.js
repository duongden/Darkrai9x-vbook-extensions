// genre.js — curated themes. Each `input` is a "curated:" query handled by
// search.js. The site has no genre taxonomy API, so these mirror its curated rows.
function execute() {
    let themes = ["Pop Hits", "Hip-Hop", "Rock", "R&B", "Country", "Chill Lofi",
                  "Focus Instrumental", "Workout", "Jazz", "Classical", "EDM",
                  "Indie", "Latin", "K-Pop", "2010s Hits"];
    let out = [];
    themes.forEach(function (t) {
        out.push({ title: t, input: "curated:" + t, script: "search.js" });
    });
    return Response.success(out);
}
