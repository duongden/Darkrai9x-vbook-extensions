load('config.js');
// artist.js — browsable list for one artist, opened via an explore/search item's
// list action (input = artist id). Returns the artist's albums followed by top
// tracks; each item links to a detail route (album, or the track's album) so
// tapping it opens the player. Single page (the artist API returns everything).
function execute(input, page) {
    let id = input;
    let m = input.match(/\/artist\/([0-9]+)/);
    if (m) id = m[1];

    let d = apiJson("/api/artist/" + id);
    if (!d || !d.artist) return Response.error("Artist not found");

    let items = [];

    (d.albums || []).forEach(function (a) {
        items.push({
            name: a.title,
            cover: coverOf(a),
            link: routeUrl("album", a.id),
            description: a.releaseDate || "Album",
            tag: "Album"
        });
    });

    (d.top || []).forEach(function (t) {
        let alb = t.album || {};
        items.push({
            name: t.title,
            cover: coverOf(alb),
            link: routeUrl("album", alb.id),
            description: (t.artist && t.artist.name) || d.artist.name,
            tag: ""
        });
    });

    return Response.success(items, "");
}
