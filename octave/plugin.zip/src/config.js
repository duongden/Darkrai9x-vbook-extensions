let BASE_URL = "https://music.octavestreaming.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

// The site is a Next.js shell; all data comes from a separate JSON API host.
// BASE_URL is the site (used for detail/toc `url` values and Referer); API_URL is
// where every fetch actually goes.
let API_URL = "https://api.octavestreaming.com";

function apiHeaders() {
    return { "User-Agent": UserAgent.chrome(), "Origin": BASE_URL, "Referer": BASE_URL + "/" };
}

// GET a JSON API path, returns the parsed object or null on failure.
function apiJson(path) {
    let r = fetch(API_URL + path, { headers: apiHeaders() });
    if (!r.ok) return null;
    return r.json();
}

// A detail/toc/chap url is a site route like "/album/123", "/playlist/123",
// "/artist/123", "/track/123", or the virtual "/chart/us" (Apple charts by
// country). Return { type, id } or null. For chart, id is the country code.
function parseRoute(url) {
    let mc = url.match(/\/chart\/([a-z]{2})/i);
    if (mc) return { type: "chart", id: mc[1].toLowerCase() };
    let m = url.match(/\/(album|playlist|artist|track)\/([0-9]+)/);
    if (!m) return null;
    return { type: m[1], id: m[2] };
}

// Selected chart country (COUNTRY config key), falling back to "us".
function chartCountry() {
    try {
        if (COUNTRY) return COUNTRY;
    } catch (error) {
    }
    return "vn";
}

// Apple artwork urls are templated with "{w}x{h}" — fill a concrete size.
function appleArt(art, size) {
    if (!art || !art.url) return "";
    return art.url.replace("{w}", size).replace("{h}", size);
}

// A chart song (from /api/apple/charts) -> a toc track entry. Its stream is
// resolved by /api/track/{appleId}, which accepts the Apple id directly.
function chartSongToTrack(s) {
    return {
        name: s.name,
        url: routeUrl("track", s.id),
        description: s.artistName || "",
        lock: false,
        pay: false
    };
}

// Build the site route for an entity — used as `link`/`url` so vBook re-enters
// detail/toc with a route parseRoute() understands.
function routeUrl(type, id) {
    return BASE_URL + "/" + type + "/" + id;
}

// Pick the biggest available cover from an album/track object.
function coverOf(obj) {
    if (!obj) return "";
    return obj.cover_xl || obj.cover_big || obj.cover_medium || obj.cover_small ||
           obj.picture_xl || obj.picture_big || obj.picture_medium || obj.picture_small ||
           obj.image || obj.picture || "";
}

// Normalize a search/home track object into a vBook item pointing at its album.
function trackToItem(t) {
    let alb = t.album || {};
    return {
        name: t.title,
        cover: coverOf(alb),
        link: routeUrl("album", alb.id),
        description: (t.artist && t.artist.name) || "",
        tag: ""
    };
}
