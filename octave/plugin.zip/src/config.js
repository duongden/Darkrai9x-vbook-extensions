let BASE_URL = "https://music.octavestreaming.com";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

// The site is a Next.js shell; all data comes from a separate JSON API host.
// BASE_URL is the site (used for detail/toc `url` values and Referer); API_URL is
// where every fetch actually goes.
let API_URL = "https://api.octavestreaming.com";

function apiHeaders() {
    return { "User-Agent": UserAgent.chrome(), "Origin": BASE_URL, "Referer": BASE_URL + "/" };
}

// GET a JSON API path, returns the parsed object or null on failure.
function apiJson(path) {
    let r = fetch(API_URL + path, { headers: apiHeaders() });
    if (!r.ok) return null;
    return r.json();
}

// A detail/toc/chap url is a site route like "/album/123", "/playlist/123",
// "/artist/123", "/track/123", the virtual "/chart/us" (Apple charts by
// country), or the virtual "/song/{q}" (a single track identified by a search
// query — used for chart items whose Apple id has no stable Deezer stream; the
// query resolves to a live Deezer track lazily). Return { type, id/query, name }.
function parseRoute(url) {
    let ms = url.match(/\/song\/([^?#]+)/);
    if (ms) {
        let q = decodeURIComponent(ms[1]);
        return { type: "song", query: q, name: q };
    }
    let mc = url.match(/\/chart\/([a-z]{2})/i);
    if (mc) return { type: "chart", id: mc[1].toLowerCase() };
    let m = url.match(/\/(album|playlist|artist|track|radio|podcast)\/([0-9]+)/);
    if (!m) return null;
    // Optional ?n=<display name> — the radio API returns only tracks (no title),
    // so the explore item passes its title through here.
    let name = "";
    let mn = url.match(/[?&]n=([^&#]+)/);
    if (mn) name = decodeURIComponent(mn[1]);
    return { type: m[1], id: m[2], name: name };
}

// Resolve a "name artist" query to a live Deezer track, returning
// { id, title, artist, cover } or null.
function resolveSong(query) {
    let d = apiJson("/api/search?q=" + encodeURIComponent(query));
    let tracks = d && d.tracks;
    if (!tracks || tracks.length === 0) return null;
    let t = tracks[0];
    let alb = t.album || {};
    return {
        id: String(t.id),
        title: t.title,
        artist: (t.artist && t.artist.name) || "",
        cover: coverOf(alb)
    };
}

// Selected chart country (COUNTRY config key), falling back to "us".
function chartCountry() {
    try {
        if (COUNTRY) return COUNTRY;
    } catch (error) {
    }
    return "vn";
}

// Apple artwork urls are templated with "{w}x{h}" — fill a concrete size.
function appleArt(art, size) {
    if (!art || !art.url) return "";
    return art.url.replace("{w}", size).replace("{h}", size);
}

// Match a chart song's name to a Deezer track id. Chart ids are Apple Music
// ids; many (esp. non-US) have no Deezer master and their /audio stream is dead
// (503, x-octave-dead), so we search the title+artist and take the first Deezer
// track. Returns the id string, or "" when nothing matches.
function chartSongDeezerId(s) {
    let q = s.name;
    if (s.artistName) q = q + " " + s.artistName;
    let d = apiJson("/api/search?q=" + encodeURIComponent(q));
    let tracks = d && d.tracks;
    if (tracks && tracks.length > 0) return String(tracks[0].id);
    return "";
}

// A chart song -> a toc track entry backed by a playable Deezer id. Returns null
// when the song has no Deezer match (caller drops it).
function chartSongToTrack(s) {
    let id = chartSongDeezerId(s);
    if (!id) return null;
    return {
        name: s.name,
        url: routeUrl("track", id),
        description: s.artistName || "",
        lock: false,
        pay: false
    };
}

// Build the site route for an entity — used as `link`/`url` so vBook re-enters
// detail/toc with a route parseRoute() understands.
function routeUrl(type, id) {
    return BASE_URL + "/" + type + "/" + id;
}

// Pick the biggest available cover from an album/track object.
function coverOf(obj) {
    if (!obj) return "";
    return obj.cover_xl || obj.cover_big || obj.cover_medium || obj.cover_small ||
           obj.picture_xl || obj.picture_big || obj.picture_medium || obj.picture_small ||
           obj.image || obj.picture || "";
}

// Normalize a search/home track object into a vBook item pointing at its album.
function trackToItem(t) {
    let alb = t.album || {};
    return {
        name: t.title,
        cover: coverOf(alb),
        link: routeUrl("album", alb.id),
        description: (t.artist && t.artist.name) || "",
        tag: ""
    };
}
