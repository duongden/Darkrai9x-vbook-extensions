load('config.js');
// explore.js — maps the site's /api/home sections to explore rows. Each section's
// item type (tracks/albums/playlists/artists) decides the detail route the item
// links to. radios/podcasts are skipped (no matching detail route).
function execute() {
    let d = apiJson("/api/home");
    if (!d || !d.sections) return Response.error("Home failed");

    let sections = [];

    // Apple-charts row is disabled: the upstream /api/track resolution for chart
    // (Apple) ids is currently unstable (503 x-octave-dead) and /api/search
    // returns no tracks/albums to resolve them by name, so chart items load but
    // don't play. Re-enable once the upstream API recovers.

    d.sections.forEach(function (s) {
        let items = [];
        (s.items || []).forEach(function (it) {
            if (s.type === "tracks") {
                items.push(trackToItem(it));
            } else if (s.type === "albums") {
                items.push({
                    name: it.title, cover: coverOf(it),
                    link: routeUrl("album", it.id),
                    description: (it.artist && it.artist.name) || ""
                });
            } else if (s.type === "playlists") {
                items.push({
                    name: it.title, cover: coverOf(it),
                    link: routeUrl("playlist", it.id),
                    description: it.user || ""
                });
            } else if (s.type === "artists") {
                items.push({
                    name: it.name, cover: coverOf(it),
                    description: "Artist",
                    // Open a browsable album/track list, not the static detail page.
                    action: { type: "list", script: "artist.js", input: it.id, data: "" }
                });
            } else if (s.type === "radios") {
                items.push({
                    name: it.title, cover: coverOf(it),
                    link: routeUrl("radio", it.id) + "?n=" + encodeURIComponent(it.title || ""),
                    description: "Radio"
                });
            } else if (s.type === "podcasts") {
                items.push({
                    name: it.title, cover: coverOf(it),
                    link: routeUrl("podcast", it.id),
                    description: it.author || "Podcast"
                });
            }
        });
        if (items.length === 0) return;
        let section = {
            id: s.id,
            title: s.title,
            subtitle: "",
            type: "horizontal_list",
            shape: s.type === "artists" ? "circle" : "square",
            items: items
        };
        // Artists row goes right after trending; everything else keeps API order.
        if (s.type === "artists") {
            let at = 0;
            for (let i = 0; i < sections.length; i++) {
                if (sections[i].id === "trending") { at = i + 1; break; }
            }
            sections.splice(at, 0, section);
        } else {
            sections.push(section);
        }
    });

    return Response.success(sections);
}
