load('config.js');
// chap.js (audio: step 1) — url is /track/{id}. Resolve to the stream handle.
// /api/track/{id} returns { url: <320kbps stream>, preview: <30s mp3> }. Prefer
// the full-quality url; fall back to preview. Return an array (never a bare
// string) so the app parses `data` off it.
function execute(url) {
    let route = parseRoute(url);
    if (!route) return Response.error("Bad url: " + url);

    let d = apiJson("/api/track/" + route.id);
    if (!d) return Response.error("Track not found");

    let stream = d.url || d.preview;
    if (!stream) return Response.error("No stream");

    return Response.success([{ title: d.quality ? (d.quality + "kbps") : "Octave", data: stream }]);
}
