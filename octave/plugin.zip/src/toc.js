load('config.js');
// toc.js (audio) — the playlist. Each entry is one track; its url is /track/{id},
// which chap.js resolves to a stream. Album keeps its own order; playlist/artist
// use the API's returned order.
function execute(url) {
    let route = parseRoute(url);
    if (!route) return Response.error("Bad url: " + url);

    if (route.type === "chart") {
        let d = apiJson("/api/apple/charts?sf=" + route.id + "&types=songs");
        let songs = d && d.results && d.results.songs;
        if (!songs || songs.length === 0) return Response.error("No chart");
        let out = [];
        songs.forEach(function (s) { out.push(chartSongToTrack(s)); });
        return Response.success(out);
    }

    let tracks;
    if (route.type === "album") {
        let d = apiJson("/api/album/" + route.id);
        tracks = d && d.album && d.album.tracks;
    } else if (route.type === "playlist") {
        let d = apiJson("/api/playlist/" + route.id);
        tracks = d && d.playlist && d.playlist.tracks;
    } else {
        let d = apiJson("/api/artist/" + route.id);
        tracks = d && d.top;
    }

    if (!tracks || tracks.length === 0) return Response.error("No tracks");

    let out = [];
    tracks.forEach(function (t) {
        out.push({
            name: t.title,
            url: routeUrl("track", t.id),
            description: (t.artist && t.artist.name) || "",
            lock: false,
            pay: false
        });
    });

    return Response.success(out);
}
