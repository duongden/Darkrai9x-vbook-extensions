load('config.js');
// toc.js (audio) — the playlist. Each entry is one track; its url is /track/{id},
// which chap.js resolves to a stream. Album keeps its own order; playlist/artist
// use the API's returned order.
function execute(url) {
    let route = parseRoute(url);
    if (!route) return Response.error("Bad url: " + url);

    if (route.type === "song") {
        let s = resolveSong(route.query);
        if (!s) return Response.error("Song not found");
        return Response.success([{
            name: s.title,
            url: routeUrl("track", s.id),
            description: s.artist,
            lock: false,
            pay: false
        }]);
    }

    if (route.type === "chart") {
        let d = apiJson("/api/apple/charts?sf=" + route.id + "&types=songs");
        let songs = d && d.results && d.results.songs;
        if (!songs || songs.length === 0) return Response.error("No chart");
        let out = [];
        songs.forEach(function (s) {
            let t = chartSongToTrack(s);
            if (t) out.push(t);
        });
        if (out.length === 0) return Response.error("No playable chart tracks");
        return Response.success(out);
    }

    if (route.type === "podcast") {
        let d = apiJson("/api/podcast/" + route.id + "/episodes");
        let eps = d && d.episodes;
        if (!eps || eps.length === 0) return Response.error("No episodes");
        let out = [];
        eps.forEach(function (e) {
            out.push({
                name: e.title,
                url: routeUrl("track", e.id),
                description: e.releaseDate || "",
                lock: false,
                pay: false
            });
        });
        return Response.success(out);
    }

    let tracks;
    if (route.type === "album") {
        let d = apiJson("/api/album/" + route.id);
        tracks = d && d.album && d.album.tracks;
    } else if (route.type === "playlist") {
        let d = apiJson("/api/playlist/" + route.id);
        tracks = d && d.playlist && d.playlist.tracks;
    } else if (route.type === "radio") {
        let d = apiJson("/api/radio/" + route.id);
        tracks = d && d.tracks;
    } else {
        let d = apiJson("/api/artist/" + route.id);
        tracks = d && d.top;
    }

    if (!tracks || tracks.length === 0) return Response.error("No tracks");

    let out = [];
    tracks.forEach(function (t) {
        out.push({
            name: t.title,
            url: routeUrl("track", t.id),
            description: (t.artist && t.artist.name) || "",
            lock: false,
            pay: false
        });
    });

    return Response.success(out);
}
